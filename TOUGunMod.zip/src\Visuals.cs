using UnityEngine;
using Object = UnityEngine.Object;

namespace TOUGunMod;

/// <summary>
/// World-space sprites: the weapon each player is holding, plus short-lived
/// effects (muzzle flash, slash arc, bullet impact). Everything here is purely
/// visual; hit logic lives in <see cref="Bullets"/> and <see cref="WeaponButton"/>.
/// </summary>
public static class Visuals
{
    private sealed class Held
    {
        public PlayerControl Owner = null!;
        public Weapon Weapon;
        public GameObject Go = null!;
        public SpriteRenderer Sr = null!;
        public float Angle;
    }

    private sealed class Effect
    {
        public GameObject Go = null!;
        public float Expires;
        public PlayerControl? Follow;
        public Vector2 Offset;
    }

    private static readonly Dictionary<byte, Held> HeldByPlayer = new();
    private static readonly List<Effect> Effects = new();

    /// <summary>Approximate hand position relative to the player transform.</summary>
    public static readonly Vector3 HandOffset = new(0.0f, -0.1f, -0.01f);

    public static float BodyHeight(PlayerControl p)
    {
        var body = p.cosmetics?.currentBodySprite?.BodySprite;
        if (body != null && body.sprite != null)
        {
            var h = body.bounds.size.y;
            if (h > 0.1f)
            {
                return h;
            }
        }

        return 0.75f;
    }

    public static float WeaponLength(PlayerControl p, Weapon w) => BodyHeight(p) * (w == Weapon.Gun ? 0.62f : 0.95f);

    public static Vector2 HandWorld(PlayerControl p) => (Vector2)(p.transform.position + HandOffset);

    public static void Show(PlayerControl p, Weapon w, float angle)
    {
        if (p == null)
        {
            return;
        }

        if (HeldByPlayer.TryGetValue(p.PlayerId, out var held))
        {
            if (held.Weapon != w || !held.Go)
            {
                Hide(p);
            }
            else
            {
                held.Angle = angle;
                return;
            }
        }

        var go = new GameObject($"GunMod_{w}_{p.PlayerId}");
        go.transform.SetParent(p.transform, false);
        go.transform.localPosition = HandOffset;
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = Art.Held(w, WeaponLength(p, w));
        HeldByPlayer[p.PlayerId] = new Held { Owner = p, Weapon = w, Go = go, Sr = sr, Angle = angle };
        Apply(HeldByPlayer[p.PlayerId]);
    }

    public static void SetAngle(PlayerControl p, float angle)
    {
        if (HeldByPlayer.TryGetValue(p.PlayerId, out var held))
        {
            held.Angle = angle;
        }
    }

    public static bool IsHolding(PlayerControl p, out Weapon weapon)
    {
        if (HeldByPlayer.TryGetValue(p.PlayerId, out var held) && held.Go)
        {
            weapon = held.Weapon;
            return true;
        }

        weapon = Weapon.Gun;
        return false;
    }

    public static void Hide(PlayerControl p)
    {
        if (p != null && HeldByPlayer.Remove(p.PlayerId, out var held) && held.Go)
        {
            Object.Destroy(held.Go);
        }
    }

    public static void HideAll()
    {
        foreach (var held in HeldByPlayer.Values)
        {
            if (held.Go)
            {
                Object.Destroy(held.Go);
            }
        }

        HeldByPlayer.Clear();
        foreach (var fx in Effects)
        {
            if (fx.Go)
            {
                Object.Destroy(fx.Go);
            }
        }

        Effects.Clear();
    }

    private static void Apply(Held held)
    {
        var p = held.Owner;
        if (!held.Go || p == null)
        {
            return;
        }

        var body = p.cosmetics?.currentBodySprite?.BodySprite;
        var visible = p.Data != null && !p.Data.IsDead && !p.inVent && p.Visible;
        if (body != null)
        {
            visible &= body.enabled && body.color.a > 0.5f;
            held.Sr.sortingLayerID = body.sortingLayerID;
            held.Sr.sortingOrder = body.sortingOrder + 1;
        }

        if (!CanLocalSee())
        {
            visible = false;
        }

        held.Sr.enabled = visible;
        held.Go.transform.localRotation = Quaternion.Euler(0, 0, held.Angle);
        var left = Mathf.Cos(held.Angle * Mathf.Deg2Rad) < 0;
        held.Go.transform.localScale = new Vector3(1, left ? -1 : 1, 1);
    }

    /// <summary>Ghosts only see weapons when the host allows it.</summary>
    public static bool CanLocalSee()
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null || me.Data == null)
        {
            return true;
        }

        return !me.Data.IsDead || Opts.General.GhostsSeeWeapons;
    }

    // ---- effects ----

    public static void MuzzleFlash(PlayerControl p, float angle)
    {
        var len = WeaponLength(p, Weapon.Gun);
        var dir = Dir(angle);
        var firing = Art.GunFiring(len);
        if (firing != null)
        {
            // Final art: the whole pistol with the flash drawn on, held in the hand for a moment.
            Spawn(firing, HandWorld(p), angle, 0.12f, p, Vector2.zero);
            return;
        }

        Spawn(Art.MuzzleFlash(len * 0.6f), HandWorld(p) + dir * len * 0.95f, angle, 0.09f, p, dir * len * 0.95f);
    }

    public static void Slash(PlayerControl p, float angle, float range)
    {
        var dir = Dir(angle);
        Spawn(Art.SlashArc(range * 1.6f), HandWorld(p) + dir * 0.1f, angle, 0.18f, p, dir * 0.1f);
    }

    public static void Impact(Vector2 at)
    {
        Spawn(Art.Impact(0.45f), at, 0, 0.25f, null, Vector2.zero);
    }

    private static void Spawn(Sprite? sprite, Vector2 at, float angle, float life, PlayerControl? follow, Vector2 offset)
    {
        if (sprite == null || !CanLocalSee())
        {
            return;
        }

        var go = new GameObject("GunMod_fx");
        go.transform.position = new Vector3(at.x, at.y, -0.02f);
        go.transform.rotation = Quaternion.Euler(0, 0, angle);
        var left = Mathf.Cos(angle * Mathf.Deg2Rad) < 0;
        go.transform.localScale = new Vector3(1, left ? -1 : 1, 1);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.sortingLayerID = SortingLayerOf(follow);
        sr.sortingOrder = 50;
        Effects.Add(new Effect { Go = go, Expires = Time.time + life, Follow = follow, Offset = offset });
    }

    private static int SortingLayerOf(PlayerControl? p)
    {
        var body = (p ?? PlayerControl.LocalPlayer)?.cosmetics?.currentBodySprite?.BodySprite;
        return body != null ? body.sortingLayerID : 0;
    }

    public static Vector2 Dir(float angle) => new(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad));

    public static float AngleOf(Vector2 dir) => Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

    public static void Tick()
    {
        foreach (var id in HeldByPlayer.Keys.ToArray())
        {
            var held = HeldByPlayer[id];
            if (!held.Go || held.Owner == null || held.Owner.Data == null || held.Owner.Data.Disconnected || held.Owner.Data.IsDead)
            {
                if (held.Go)
                {
                    Object.Destroy(held.Go);
                }

                HeldByPlayer.Remove(id);
                continue;
            }

            Apply(held);
        }

        for (var i = Effects.Count - 1; i >= 0; i--)
        {
            var fx = Effects[i];
            if (!fx.Go || Time.time >= fx.Expires)
            {
                if (fx.Go)
                {
                    Object.Destroy(fx.Go);
                }

                Effects.RemoveAt(i);
                continue;
            }

            if (fx.Follow != null)
            {
                var at = HandWorld(fx.Follow) + fx.Offset;
                fx.Go.transform.position = new Vector3(at.x, at.y, -0.02f);
            }
        }
    }
}
