using MiraAPI.Hud;
using MiraAPI.Networking;
using MiraAPI.PluginLoading;
using MiraAPI.Utilities.Assets;
using UnityEngine;

namespace TOUGunMod;

/// <summary>
/// Shared behaviour for the Gun and Sword buttons. First click draws the
/// weapon (it follows the mouse), second click - or a left click on the map -
/// uses it. Uses and cooldowns come from the host's per-team settings.
/// </summary>
[MiraIgnore]
public abstract class WeaponButton : CustomActionButton
{
    public abstract Weapon Kind { get; }

    protected WeaponOptions Options => Opts.For(Kind);

    public override float Cooldown => Options.Cooldown(Teams.Local);

    public override float InitialCooldown => Options.CooldownAtRoundStart ? Cooldown : 0f;

    public override int MaxUses => Options.Uses(Teams.Local);

    public override ButtonUsesMode UsesMode => ButtonUsesMode.PerGame;

    public override bool ZeroIsInfinite => true;

    public override ButtonLocation Location { get; set; } = ButtonLocation.BottomLeft;

    public override bool Enabled(RoleBehaviour? role)
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null || me.Data == null || LobbyBehaviour.Instance != null)
        {
            return false;
        }

        return Options.Enabled && !me.Data.IsDead && Options.TeamGets(Teams.Local);
    }

    public override void CreateButton(Transform parent)
    {
        // Match the vanilla icon size so custom art sits at the same scale.
        var vanilla = HudManager.Instance?.AbilityButton?.graphic?.sprite;
        if (vanilla != null && vanilla.bounds.size.x > 0.1f)
        {
            Art.ButtonIconUnits = vanilla.bounds.size.x;
        }

        base.CreateButton(parent);
    }

    /// <summary>Button pressed: draw if holstered, otherwise use the weapon.</summary>
    public override void ClickHandler()
    {
        if (!CanClick())
        {
            return;
        }

        if (Aim.Drawn == Kind)
        {
            Fire();
        }
        else
        {
            Aim.Draw(Kind);
        }
    }

    protected override void OnClick()
    {
        // Handled in ClickHandler so drawing the weapon does not spend a use.
    }

    public void Fire()
    {
        if (Aim.Drawn != Kind || !CanClick())
        {
            return;
        }

        if (LimitedUses)
        {
            SetUses(UsesLeft - 1);
        }

        Use(Aim.Angle);
        Timer = Cooldown;
        Aim.Consumed();
    }

    protected abstract void Use(float angle);

    /// <summary>Apply the refund / attacker-dies rules for one hit, then kill the victim.</summary>
    public void OnHit(PlayerControl victim)
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null || victim == null || victim.Data == null || victim.Data.IsDead)
        {
            return;
        }

        var attacker = Teams.Local;
        var target = Teams.Of(victim);
        var general = Opts.General;

        me.RpcCustomMurder(
            victim,
            didSucceed: true,
            resetKillTimer: false,
            createDeadBody: general.LeaveBody,
            teleportMurderer: false,
            showKillAnim: general.KillAnimation,
            playKillSound: true);

        if (Options.Refund(attacker, target) && LimitedUses)
        {
            SetUses(UsesLeft + 1);
        }

        if (Options.AttackerDies(attacker, target) && victim.PlayerId != me.PlayerId)
        {
            me.RpcCustomMurder(
                me,
                didSucceed: true,
                resetKillTimer: false,
                createDeadBody: general.LeaveBody,
                teleportMurderer: false,
                showKillAnim: general.KillAnimation,
                playKillSound: true);
        }
    }

    /// <summary>Round start / meeting end: refill uses and restart the cooldown per the host settings.</summary>
    public void ResetForRound(bool intro)
    {
        if (Button == null)
        {
            return;
        }

        if (intro || Opts.General.ResetAfterMeeting)
        {
            if (MaxUses > 0)
            {
                SetUses(MaxUses);
            }
            else
            {
                UsesLeft = 0;
                Button.SetInfiniteUses();
            }
        }

        Timer = intro ? InitialCooldown : Cooldown;
    }
}

public sealed class GunButton : WeaponButton
{
    public override Weapon Kind => Weapon.Gun;
    public override string Name => "Gun";
    public override LoadableAsset<Sprite> Sprite => Art.GunButton;
    public override Color TextOutlineColor => new(0.42f, 0.5f, 0.62f);

    protected override void Use(float angle)
    {
        var me = PlayerControl.LocalPlayer;
        var dir = Visuals.Dir(angle);
        var origin = Visuals.HandWorld(me) + dir * (Visuals.WeaponLength(me, Weapon.Gun) * 0.9f);
        Net.RpcFireBullet(me, Bullets.NextId(), origin.x, origin.y, dir.x, dir.y, angle);
    }
}

public sealed class SwordButton : WeaponButton
{
    public override Weapon Kind => Weapon.Sword;
    public override string Name => "Sword";
    public override LoadableAsset<Sprite> Sprite => Art.SwordButton;
    public override Color TextOutlineColor => new(0.79f, 0.6f, 0.18f);

    protected override void Use(float angle)
    {
        var me = PlayerControl.LocalPlayer;
        var opts = Opts.Sword;
        var range = opts.SwordRange.Value;
        var halfArc = opts.SwordArc.Value * 0.5f;
        var dir = Visuals.Dir(angle);
        var origin = me.GetTruePosition();

        var hits = new List<(PlayerControl p, float dist)>();
        foreach (var p in PlayerControl.AllPlayerControls.ToArray())
        {
            if (p == null || p.Data == null || p.PlayerId == me.PlayerId || p.Data.IsDead || p.Data.Disconnected || p.inVent || !p.Visible)
            {
                continue;
            }

            var to = p.GetTruePosition() - origin;
            var dist = to.magnitude;
            if (dist > range)
            {
                continue;
            }

            if (dist > 0.05f && Vector2.Angle(dir, to) > halfArc)
            {
                continue;
            }

            if (PhysicsHelpers.AnythingBetween(origin, p.GetTruePosition(), Constants.ShipOnlyMask, false))
            {
                continue;
            }

            hits.Add((p, dist));
        }

        hits.Sort((a, b) => a.dist.CompareTo(b.dist));
        if (!opts.SwordHitsAll && hits.Count > 1)
        {
            hits.RemoveRange(1, hits.Count - 1);
        }

        var first = hits.Count > 0 ? hits[0].p.PlayerId : byte.MaxValue;
        Net.RpcSwing(me, angle, range, first);
        foreach (var (p, _) in hits)
        {
            OnHit(p);
        }
    }
}

/// <summary>Cached lookups for the two button singletons.</summary>
public static class CustomButtonRef
{
    public static GunButton? Gun => Safe<GunButton>();
    public static SwordButton? Sword => Safe<SwordButton>();

    public static WeaponButton? For(Weapon weapon) => weapon == Weapon.Gun ? Gun : Sword;

    private static T? Safe<T>() where T : CustomActionButton
    {
        try
        {
            return CustomButtonSingleton<T>.Instance;
        }
        catch
        {
            return null;
        }
    }
}
