@echo off
setlocal
cd /d "%~dp0"
set GAME=C:\Program Files (x86)\Steam2\steamapps\common\Among Us

rem Pull the final art into Resources when it exists (Blender renders stay as fallbacks).
for %%n in (gun_button sword_button gun_held gun_firing sword_held bullet muzzle_flash slash_arc bullet_hit) do (
  if exist "art\%%n.png" copy /y "art\%%n.png" "Resources\%%n.png" >nul
)

dotnet build -c Release -nologo -v q --no-incremental
if errorlevel 1 exit /b 1

copy /y "bin\Release\net6.0\TOUGunMod.dll" "%GAME%\BepInEx\plugins\TOUGunMod.dll"
if errorlevel 1 (
  echo Could not copy into the game folder - is Among Us running?
  exit /b 1
)
echo Installed TOUGunMod.dll into BepInEx\plugins.
