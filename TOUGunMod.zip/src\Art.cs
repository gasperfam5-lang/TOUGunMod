using System.Reflection;
using MiraAPI.Utilities.Assets;
using UnityEngine;

namespace TOUGunMod;

/// <summary>
/// Sprite loading. Each image has a preferred name (the final art) and a
/// fallback (the Blender render) so the mod works before the final art lands.
/// </summary>
public static class Art
{
    private const string Prefix = "TOUGunMod.Resources.";
    private static readonly Assembly Asm = typeof(Art).Assembly;
    private static readonly Dictionary<string, Sprite> Cache = new();

    /// <summary>World size of a vanilla ability button icon, read when the buttons are built.</summary>
    public static float ButtonIconUnits { get; set; } = 1.15f;

    public static LoadableAsset<Sprite> GunButton { get; } = new ButtonSprite("gun_button", "gun_icon");
    public static LoadableAsset<Sprite> SwordButton { get; } = new ButtonSprite("sword_button", "sword_icon");

    // Pivots are where the crewmate's hand goes, measured on the final art
    // (grip centre of the pistol, grip of the sword).
    public static Sprite? Held(Weapon weapon, float lengthUnits)
    {
        return weapon == Weapon.Gun
            ? Load(lengthUnits, new Vector2(0.15f, 0.23f), "gun_held", "gun_icon")
            : Load(lengthUnits, new Vector2(0.16f, 0.5f), "sword_held", "sword_icon");
    }

    /// <summary>The pistol with its muzzle flash baked in; shown for a moment when firing. Null without the final art.</summary>
    public static Sprite? GunFiring(float gunLengthUnits)
    {
        // The pistol occupies 806 of this image's 1024 px, so scale so the gun itself matches the held sprite.
        return Find("gun_firing") == null ? null : Load(gunLengthUnits * 1024f / 806f, new Vector2(0.118f, 0.28f), "gun_firing");
    }

    public static Sprite? Bullet(float lengthUnits) => Load(lengthUnits, new Vector2(0.5f, 0.5f), "bullet", "bullet_fallback");
    public static Sprite? MuzzleFlash(float lengthUnits) => Load(lengthUnits, new Vector2(0.1f, 0.5f), "muzzle_flash", "muzzle_flash_fallback");
    public static Sprite? SlashArc(float lengthUnits) => Load(lengthUnits, new Vector2(0.35f, 0.5f), "slash_arc", "slash_arc_fallback");
    public static Sprite? Impact(float lengthUnits) => Load(lengthUnits, new Vector2(0.5f, 0.5f), "bullet_hit", "bullet_hit_fallback");

    private static string? Find(params string[] names)
    {
        var all = Asm.GetManifestResourceNames();
        foreach (var n in names)
        {
            var full = Prefix + n + ".png";
            if (all.Contains(full))
            {
                return full;
            }
        }

        return null;
    }

    /// <summary>Loads a sprite scaled so its width is <paramref name="lengthUnits"/> world units.</summary>
    private static Sprite? Load(float lengthUnits, Vector2 pivot, params string[] names)
    {
        var key = $"{string.Join("|", names)}@{lengthUnits:0.000}";
        if (Cache.TryGetValue(key, out var cached) && cached)
        {
            return cached;
        }

        var path = Find(names);
        if (path == null)
        {
            return null;
        }

        var tex = SpriteTools.LoadTextureFromResourcePath(path, Asm);
        tex.filterMode = FilterMode.Bilinear;
        var ppu = tex.width / Mathf.Max(0.01f, lengthUnits);
        var sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), pivot, ppu);
        sprite.name = path;
        sprite.hideFlags = HideFlags.DontUnloadUnusedAsset;
        Cache[key] = sprite;
        return sprite;
    }

    private sealed class ButtonSprite(string preferred, string fallback) : LoadableAsset<Sprite>
    {
        public override Sprite LoadAsset()
        {
            if (LoadedAsset)
            {
                return LoadedAsset!;
            }

            var sprite = Load(ButtonIconUnits, new Vector2(0.5f, 0.5f), preferred, fallback);
            if (sprite == null)
            {
                // No art at all - fall back to the vanilla ability icon so the button still works.
                sprite = HudManager.Instance.AbilityButton.graphic.sprite;
            }

            LoadedAsset = sprite;
            return sprite;
        }
    }
}
