# TOUGunMod - host settings

All of these live in the lobby settings under the mod's three groups: Gun,
Sword, and "Gun and Sword general". "Infinite" is a real value for every
count (shown as the infinity sign at 0). Cooldowns are seconds. Ranges are
game units (vanilla kill distance Short ~1.0, Medium ~1.8, Long ~2.5).

## Gun (the Sword group has the identical list, with the sword-only lines swapped in)
- Gun enabled (master toggle; everything below hides when off)
- Crewmates / Impostors / Neutrals get a gun (three toggles)
- Crewmate / Impostor / Neutral gun shots (1..20, 0 = infinite) - defaults 1 / inf / inf
- Crewmate / Impostor / Neutral gun cooldown (0..120 s) - default 25 s each
- Gun cooldown starts at round start (toggle) - off = ready immediately
- Shot back after hitting an impostor / neutral / crewmate - one toggle per attacker team
  (9 toggles; defaults: crew gets it back for imp + neutral, imp for crew + neutral, neutral for everyone)
- Attacker dies when the gun hits a crewmate / impostor / neutral - one toggle per attacker team
  (9 toggles; default: only "Crewmate dies when gun hits a crewmate" is on)
- Bullet speed (2..60 units/s, default 12)
- Bullet max distance (5..100, 0 = infinite)
- Bullet blocked by walls (toggle; off = goes through everything)
- Bullet goes through players it hits (toggle)
- Your own bullet can hit you (toggle)
- Gun aim: Mouse (gun follows the cursor) / Facing (fires the way you are walking)
- Gun auto-holsters after (1..30 s, 0 = no limit)
- Others can see your gun while aiming (toggle)
- Impostors keep their normal kill with the gun (toggle; off hides the vanilla Kill button)

Sword-only lines (replace the bullet lines above):
- Sword range (0.5..5.0, default 1.8)
- Sword swing arc in degrees (30..360, default 120; 360 = anyone in range)
- Sword hits everyone in the arc (toggle; off = closest only)

## Gun and Sword general
- Weapon kills leave a body (toggle; off = victim vanishes)
- Weapon kills show the kill animation (toggle)
- Ghosts can see weapons and bullets (toggle)
- Weapons refill after every meeting (toggle)
- Only one weapon can be drawn at a time (toggle)
- Announce weapon kills in chat (toggle) - "X shot Y" / "X slashed Y"
- Show a popup when you hit someone (toggle)

## Controls
- Click Gun / Sword (or its keybind) to draw. The weapon follows the mouse.
- Left click anywhere on the map, or click the button again, to fire / swing.
- Right click or Escape puts it away without using a shot.
- A meeting, dying, venting, or the auto-holster timer also puts it away.
