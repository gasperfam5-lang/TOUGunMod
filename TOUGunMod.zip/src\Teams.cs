using TownOfUs.Utilities;

namespace TOUGunMod;

public enum Team
{
    Crewmate,
    Impostor,
    Neutral,
}

public enum Weapon : byte
{
    Gun = 0,
    Sword = 1,
}

public enum AimMode
{
    Mouse,
    Facing,
}

public static class Teams
{
    public static Team Of(PlayerControl? player)
    {
        if (player == null || player.Data == null || player.Data.Role == null)
        {
            return Team.Crewmate;
        }

        if (player.IsImpostor())
        {
            return Team.Impostor;
        }

        return player.IsNeutral() ? Team.Neutral : Team.Crewmate;
    }

    public static Team Local => Of(PlayerControl.LocalPlayer);

    public static string Name(Team team) => team switch
    {
        Team.Impostor => "impostor",
        Team.Neutral => "neutral",
        _ => "crewmate",
    };
}
