using BepInEx;
using BepInEx.Configuration;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using MiraAPI;
using MiraAPI.PluginLoading;
using Reactor;
using Reactor.Networking;
using Reactor.Networking.Attributes;
using TownOfUs;

namespace TOUGunMod;

[BepInPlugin(Id, "TOUGunMod", Version)]
[BepInProcess("Among Us.exe")]
[BepInDependency(ReactorPlugin.Id)]
[BepInDependency(MiraApiPlugin.Id)]
[BepInDependency(TownOfUsPlugin.Id)]
[ReactorModFlags(ModFlags.RequireOnAllClients)]
public sealed class GunModPlugin : BasePlugin, IMiraPlugin
{
    public const string Id = "bengy767.tou.gunsword";
    public const string Version = "1.0.0";

    public static GunModPlugin Instance { get; private set; } = null!;

    public Harmony Harmony { get; } = new(Id);

    public string OptionsTitleText => "Gun & Sword";

    public ConfigFile GetConfigFile() => Config;

    public override void Load()
    {
        Instance = this;
        Harmony.PatchAll();
        Log.LogInfo($"TOUGunMod {Version} loaded.");
    }
}
