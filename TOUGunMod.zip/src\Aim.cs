using UnityEngine;

namespace TOUGunMod;

/// <summary>
/// The local player's drawn weapon: which one is out, where it points, and the
/// mouse handling that fires or holsters it. Remote players only ever see the
/// results through <see cref="Net"/>.
/// </summary>
public static class Aim
{
    public static Weapon? Drawn { get; private set; }
    public static float Angle { get; private set; }

    private static float _drawnAt;
    private static float _lastSent;
    private static float _lastSentAngle = float.NaN;
    private static Vector2 _facing = Vector2.right;
    private static int _uiMask = -1;

    public static Vector2 Direction => Visuals.Dir(Angle);

    public static void Draw(Weapon weapon)
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null)
        {
            return;
        }

        if (Drawn.HasValue && Drawn.Value != weapon)
        {
            if (Opts.General.OneWeaponAtATime)
            {
                Holster();
            }
            else
            {
                // Two weapons drawn at once is allowed, but only one can be shown in the hand.
                Visuals.Hide(me);
            }
        }

        Drawn = weapon;
        _drawnAt = Time.time;
        UpdateAngle(me, force: true);
        Visuals.Show(me, weapon, Angle);
        Send(true, force: true);
    }

    public static void Holster()
    {
        var me = PlayerControl.LocalPlayer;
        if (!Drawn.HasValue)
        {
            return;
        }

        Drawn = null;
        if (me != null)
        {
            Visuals.Hide(me);
        }

        Send(false, force: true);
    }

    /// <summary>Called after a shot or swing: the hand is empty again, others are told.</summary>
    public static void Consumed()
    {
        Drawn = null;
        _lastSentAngle = float.NaN;
        var me = PlayerControl.LocalPlayer;
        if (me != null)
        {
            Visuals.Hide(me);
        }
    }

    public static void Tick()
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null || me.Data == null)
        {
            return;
        }

        TrackFacing(me);

        if (!Drawn.HasValue)
        {
            return;
        }

        var weapon = Drawn.Value;
        var opts = Opts.For(weapon);
        var button = CustomButtonRef.For(weapon);

        var mustHolster = me.Data.IsDead
                          || MeetingHud.Instance != null
                          || ExileController.Instance != null
                          || !me.moveable
                          || !opts.Enabled
                          || button == null
                          || !button.Enabled(me.Data.Role)
                          || (opts.AimTimeLimit.Value > 0 && Time.time - _drawnAt > opts.AimTimeLimit.Value);
        if (mustHolster)
        {
            Holster();
            return;
        }

        UpdateAngle(me, force: false);
        Visuals.SetAngle(me, Angle);
        Send(true, force: false);

        // Right click or Escape puts the weapon away; left click on the map fires.
        if (Input.GetMouseButtonDown(1) || Input.GetKeyDown(KeyCode.Escape))
        {
            Holster();
            return;
        }

        if (Input.GetMouseButtonDown(0) && Time.time - _drawnAt > 0.15f && !MouseOverHud())
        {
            button!.Fire();
        }
    }

    private static void UpdateAngle(PlayerControl me, bool force)
    {
        var mode = Drawn.HasValue ? Opts.For(Drawn.Value).Aim.Value : AimMode.Mouse;
        Vector2 dir;
        if (mode == AimMode.Facing)
        {
            dir = _facing;
        }
        else
        {
            var cam = Camera.main;
            if (cam == null)
            {
                return;
            }

            var mouse = (Vector2)cam.ScreenToWorldPoint(Input.mousePosition);
            dir = mouse - Visuals.HandWorld(me);
            if (dir.sqrMagnitude < 0.0001f)
            {
                dir = _facing;
            }
        }

        Angle = Visuals.AngleOf(dir.normalized);
    }

    private static void TrackFacing(PlayerControl me)
    {
        var physics = me.MyPhysics;
        if (physics == null)
        {
            return;
        }

        var v = physics.Velocity;
        if (v.sqrMagnitude > 0.01f)
        {
            _facing = v.normalized;
        }
        else if (me.cosmetics != null)
        {
            // Standing still: face the way the body sprite faces.
            var flipped = me.cosmetics.FlipX;
            if (Mathf.Abs(_facing.x) < 0.01f || (flipped && _facing.x > 0) || (!flipped && _facing.x < 0))
            {
                _facing = flipped ? Vector2.left : Vector2.right;
            }
        }
    }

    private static void Send(bool drawn, bool force)
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null || !Drawn.HasValue && drawn)
        {
            return;
        }

        var weapon = Drawn ?? Weapon.Gun;
        if (!force)
        {
            if (Time.time - _lastSent < 0.12f)
            {
                return;
            }

            if (!float.IsNaN(_lastSentAngle) && Mathf.Abs(Mathf.DeltaAngle(_lastSentAngle, Angle)) < 2f)
            {
                return;
            }
        }

        _lastSent = Time.time;
        _lastSentAngle = drawn ? Angle : float.NaN;
        Net.RpcAim(me, (byte)weapon, drawn, Angle);
    }

    private static bool MouseOverHud()
    {
        var cam = Camera.main;
        if (cam == null)
        {
            return false;
        }

        if (_uiMask < 0)
        {
            var layer = LayerMask.NameToLayer("UI");
            _uiMask = layer >= 0 ? 1 << layer : 0;
        }

        if (_uiMask == 0)
        {
            return false;
        }

        var world = (Vector2)cam.ScreenToWorldPoint(Input.mousePosition);
        return Physics2D.OverlapPoint(world, _uiMask) != null;
    }
}
