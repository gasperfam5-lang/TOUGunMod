# TOUGunMod

Every player can get a **gun** and/or a **sword**. Click the button, the weapon pops out of your crewmate and follows your mouse, click again to use it. Hit an impostor or a neutral and you get your shot back (after a cooldown). Hit a crewmate and, by default, you die for it. The host decides all of that in the lobby settings — every number and every rule is adjustable, and infinite shots is a real option.

Made by Bengy767. Requires Among Us v18 (2026.8.18) with Town of Us Mira 1.7.3.

## Features

- **Gun** — infinite range. Fires a bullet that actually flies across the map at the host's chosen speed, so long shots can be dodged. First player it touches dies (or it pierces everyone, if the host wants). Optional wall blocking.
- **Sword** — melee. Swings at the closest player in front of you within the host's range and arc (or everyone in the arc).
- Both weapons aim at the mouse (or the way you're walking, host's choice).
- Everyone in the lobby sees drawn weapons, bullets, muzzle flashes and slashes.
- Per-team rules: crewmates, impostors and neutrals each have their own shot count, cooldown, refund rules and "attacker dies" rules.
- Kills go through Town of Us's normal kill path, so shields, protections and bodies all behave like any other kill.

## Install

1. Have Town of Us Mira 1.7.3 installed and working (it brings BepInEx, Reactor and MiraAPI with it).
2. Download `TOUGunMod.dll` from the Releases page.
3. Drop it into `Among Us\BepInEx\plugins\` next to `TownOfUsMira.dll`.
4. Launch through Steam. The lobby settings get three new groups: **Gun**, **Sword**, and **Gun and Sword general**.

Every player in the lobby needs the mod (it's flagged as required on all clients).

## Controls

| Action | How |
| --- | --- |
| Draw the gun / sword | Click its button in the bottom-left |
| Aim | Move the mouse — the weapon turns with it |
| Fire / swing | Left click anywhere on the map, or click the button again |
| Put it away (no shot used) | Right click or Escape |

A meeting, dying, entering a vent, or the host's auto-holster timer also puts the weapon away.

## Settings

All of these are in the lobby settings. "∞" is a real value for every count (it's what 0 shows as). Cooldowns are seconds; distances are game units (vanilla kill distance Short ≈ 1.0, Medium ≈ 1.8, Long ≈ 2.5).

### Gun

| Setting | Default | Range |
| --- | --- | --- |
| Gun enabled | on | master toggle, hides everything below when off |
| Crewmates / Impostors / Neutrals get a gun | on / on / on | |
| Crewmate / Impostor / Neutral gun shots | 1 / ∞ / ∞ | 1–20, 0 = ∞ |
| Crewmate / Impostor / Neutral gun cooldown | 25 s each | 0–120 s |
| Gun cooldown starts at round start | on | off = ready immediately |
| *Team* gets shot back after hitting an impostor / neutral / crewmate | crew: imp ✓ neutral ✓ crew ✗ · imp: crew ✓ neutral ✓ imp ✗ · neutral: all ✓ | 9 toggles |
| *Team* dies when gun hits a crewmate / impostor / neutral | only "Crewmate dies when gun hits a crewmate" is on | 9 toggles |
| Bullet speed | 12 | 2–60 units/s |
| Bullet max distance | ∞ | 5–100, 0 = ∞ |
| Bullet blocked by walls | off | off = goes through everything |
| Bullet goes through players it hits | off | |
| Your own bullet can hit you | off | |
| Gun aim | Mouse | Mouse / Facing |
| Gun auto-holsters after | ∞ (no limit) | 1–30 s |
| Others can see your gun while aiming | on | |
| Impostors keep their normal kill with the gun | on | off hides the vanilla Kill button |

### Sword

Identical list to the gun (enabled, per-team access, swings, cooldowns, refund grid, dies grid, aim, auto-holster, visibility, impostor kill button) plus:

| Setting | Default | Range |
| --- | --- | --- |
| Sword range | 1.8 | 0.5–5.0 |
| Sword swing arc | 120° | 30–360°, 360 = anyone in range |
| Sword hits everyone in the arc | off | off = closest only |

### Gun and Sword general

| Setting | Default |
| --- | --- |
| Weapon kills leave a body | on |
| Weapon kills show the kill animation | on |
| Ghosts can see weapons and bullets | on |
| Weapons refill after every meeting | off |
| Only one weapon can be drawn at a time | on |
| Announce weapon kills in chat | on |
| Show a popup when you hit someone | on |

## Building from source

Requirements: .NET 6 SDK and an Among Us install with Town of Us Mira 1.7.3 (the project references the game's own `BepInEx\interop`, `BepInEx\core` and `BepInEx\plugins` DLLs directly — no NuGet feeds needed).

```
build.cmd
```

`build.cmd` copies any final art from `art\` into `Resources\`, builds Release, and copies `TOUGunMod.dll` into the game's plugins folder. If your game is somewhere else, either edit `GAME=` in `build.cmd` and `GameDir` in `TOUGunMod.csproj`, or build with:

```
dotnet build -c Release -p:GameDir="D:\path\to\Among Us"
```

The game must be closed when you build, or the copy into `plugins` fails.

## Project layout

```
TOUGunMod.csproj      project file (net6.0, references the game's DLLs)
build.cmd             one-click build + install
src/
  Plugin.cs           BepInEx entry point, MiraAPI plugin registration
  Options.cs          every host setting (Gun, Sword, general)
  Buttons.cs          the Gun and Sword buttons: draw, fire, refund / dies rules
  Aim.cs              local aiming: mouse tracking, click to fire, holster
  Bullets.cs          bullet flight and hit detection (shooter decides hits)
  Visuals.cs          held weapon sprites, muzzle flash, slash arc, impact
  Net.cs              RPCs so everyone sees aims, bullets and swings
  Teams.cs            crewmate / impostor / neutral classification
  Art.cs              sprite loading with fallbacks
  Patches.cs          per-frame tick, round / meeting resets, kill-button hiding
Resources/            images embedded into the DLL
art/                  source art: Blender icon script, placeholder effect script, final images
SETTINGS.md           plain-text list of every setting
```

## How it works, briefly

- Buttons are MiraAPI `CustomActionButton`s. The first click draws (no shot spent), the second click fires.
- Bullets are simulated on every client so they look the same for everyone, but only the shooter's client decides hits — the same authority model vanilla uses for kills. The shooter then tells everyone where the bullet ended.
- Kills use MiraAPI's `RpcCustomMurder` (host-confirmed), so Town of Us shields and death handling apply.
- Team checks use Town of Us's own `IsImpostor()` / `IsNeutral()` helpers, so every TOU role is classified the way TOU classifies it.

## Credits

- [Town of Us Mira](https://github.com/AU-Avengers/TOU-Mira) by AU-Avengers
- [MiraAPI](https://github.com/All-Of-Us-Mods/MiraAPI) by All Of Us
- [Reactor](https://github.com/NuclearPowered/Reactor) and [BepInEx](https://github.com/BepInEx/BepInEx)
