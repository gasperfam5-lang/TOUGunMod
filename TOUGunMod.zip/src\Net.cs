using MiraAPI.Utilities;
using Reactor.Networking.Attributes;
using Reactor.Networking.Rpc;
using UnityEngine;

namespace TOUGunMod;

public enum RpcId : uint
{
    Aim = 700,
    FireBullet = 701,
    BulletHit = 702,
    BulletEnd = 703,
    Swing = 704,
}

/// <summary>
/// Everything that has to be seen by other players. Kills themselves go
/// through MiraAPI's RpcCustomMurder so shields, host confirmation and
/// TOU's death handling all keep working.
/// </summary>
public static class Net
{
    /// <summary>A player drew, moved or holstered a weapon. Local player handles its own visuals.</summary>
    [MethodRpc((uint)RpcId.Aim, LocalHandling = RpcLocalHandling.None)]
    public static void RpcAim(PlayerControl player, byte weapon, bool drawn, float angle)
    {
        if (player == null || player.AmOwner)
        {
            return;
        }

        var w = (Weapon)weapon;
        if (!drawn || !Opts.For(w).VisibleToOthers)
        {
            Visuals.Hide(player);
            return;
        }

        Visuals.Show(player, w, angle);
        Visuals.SetAngle(player, angle);
    }

    [MethodRpc((uint)RpcId.FireBullet, LocalHandling = RpcLocalHandling.Before)]
    public static void RpcFireBullet(PlayerControl shooter, ushort id, float ox, float oy, float dx, float dy, float angle)
    {
        if (shooter == null)
        {
            return;
        }

        Visuals.MuzzleFlash(shooter, angle);
        Bullets.Spawn(shooter, id, new Vector2(ox, oy), new Vector2(dx, dy));
        if (!shooter.AmOwner)
        {
            Visuals.Hide(shooter);
        }
    }

    [MethodRpc((uint)RpcId.BulletHit, LocalHandling = RpcLocalHandling.Before)]
    public static void RpcBulletHit(PlayerControl shooter, ushort id, float x, float y, byte victimId)
    {
        if (shooter == null)
        {
            return;
        }

        Visuals.Impact(new Vector2(x, y));
        var victim = Find(victimId);
        Announce(shooter, victim, Weapon.Gun);
    }

    [MethodRpc((uint)RpcId.BulletEnd, LocalHandling = RpcLocalHandling.Before)]
    public static void RpcBulletEnd(PlayerControl shooter, ushort id, float x, float y, bool impact)
    {
        Bullets.End(shooter, id, new Vector2(x, y), impact);
    }

    [MethodRpc((uint)RpcId.Swing, LocalHandling = RpcLocalHandling.Before)]
    public static void RpcSwing(PlayerControl swinger, float angle, float range, byte victimId)
    {
        if (swinger == null)
        {
            return;
        }

        Visuals.Slash(swinger, angle, range);
        if (!swinger.AmOwner)
        {
            Visuals.Hide(swinger);
        }

        var victim = Find(victimId);
        Announce(swinger, victim, Weapon.Sword);
    }

    private static PlayerControl? Find(byte id)
    {
        if (id == byte.MaxValue)
        {
            return null;
        }

        foreach (var p in PlayerControl.AllPlayerControls.ToArray())
        {
            if (p.PlayerId == id)
            {
                return p;
            }
        }

        return null;
    }

    private static void Announce(PlayerControl attacker, PlayerControl? victim, Weapon weapon)
    {
        if (victim == null || attacker.Data == null || victim.Data == null)
        {
            return;
        }

        var verb = weapon == Weapon.Gun ? "shot" : "slashed";
        if (Opts.General.AnnounceKills && HudManager.InstanceExists && HudManager.Instance.Chat != null)
        {
            HudManager.Instance.Chat.AddChat(attacker, $"<color=#FF5A5A>{verb} {victim.Data.PlayerName}</color>", false);
        }

        if (Opts.General.ShowHitPopup && attacker.AmOwner)
        {
            Helpers.CreateAndShowNotification($"<b>You {verb} {victim.Data.PlayerName}</b>", Color.white);
        }
    }
}
