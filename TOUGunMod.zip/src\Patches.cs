using HarmonyLib;
using MiraAPI.Events;
using MiraAPI.Events.Vanilla.Gameplay;
using MiraAPI.Events.Vanilla.Meeting;

namespace TOUGunMod;

[HarmonyPatch(typeof(HudManager))]
public static class HudPatches
{
    [HarmonyPostfix]
    [HarmonyPriority(Priority.Last)]
    [HarmonyPatch(nameof(HudManager.Update))]
    public static void UpdatePostfix(HudManager __instance)
    {
        try
        {
            Aim.Tick();
            Bullets.Tick();
            Visuals.Tick();
            HideVanillaKill(__instance);
            HideWhenDead();
        }
        catch (Exception e)
        {
            GunModPlugin.Instance.Log.LogError($"Gun and Sword tick failed: {e}");
        }
    }

    [HarmonyPostfix]
    [HarmonyPatch(nameof(HudManager.Start))]
    public static void StartPostfix()
    {
        Aim.Holster();
        Bullets.ClearAll();
        Visuals.HideAll();
    }

    /// <summary>Dead players never keep a weapon button on screen, whatever state the HUD is in.</summary>
    private static void HideWhenDead()
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null || me.Data == null || !me.Data.IsDead)
        {
            return;
        }

        foreach (var button in new WeaponButton?[] { CustomButtonRef.Gun, CustomButtonRef.Sword })
        {
            if (button?.Button != null && button.Button.gameObject.activeSelf)
            {
                button.Button.ToggleVisible(false);
            }
        }
    }

    /// <summary>Impostors lose the normal kill button when the host turns that off for a weapon they hold.</summary>
    private static void HideVanillaKill(HudManager hud)
    {
        var me = PlayerControl.LocalPlayer;
        if (me == null || me.Data == null || me.Data.Role == null || !me.Data.Role.IsImpostor || hud.KillButton == null)
        {
            return;
        }

        var gun = Opts.Gun;
        var sword = Opts.Sword;
        var loseKill = (gun.Enabled && gun.ImpostorsGet && !gun.ImpostorsKeepKill)
                       || (sword.Enabled && sword.ImpostorsGet && !sword.ImpostorsKeepKill);
        if (loseKill && hud.KillButton.gameObject.activeSelf)
        {
            hud.KillButton.ToggleVisible(false);
        }
    }
}

public static class EventHandlers
{
    [RegisterEvent]
    public static void OnRoundStart(RoundStartEvent e)
    {
        Aim.Holster();
        Bullets.ClearAll();
        Visuals.HideAll();
        CustomButtonRef.Gun?.ResetForRound(e.TriggeredByIntro);
        CustomButtonRef.Sword?.ResetForRound(e.TriggeredByIntro);
    }

    [RegisterEvent]
    public static void OnMeetingStart(StartMeetingEvent e)
    {
        Aim.Holster();
        Bullets.ClearAll();
        Visuals.HideAll();
    }

    [RegisterEvent]
    public static void OnGameEnd(GameEndEvent e)
    {
        Aim.Holster();
        Bullets.ClearAll();
        Visuals.HideAll();
    }
}
