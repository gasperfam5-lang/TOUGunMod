using UnityEngine;
using Object = UnityEngine.Object;

namespace TOUGunMod;

/// <summary>
/// Bullets fly on every client (so everyone sees them), but only the shooter's
/// client decides hits - the same authority model vanilla uses for kills. The
/// shooter then tells everyone where the bullet ended.
/// </summary>
public static class Bullets
{
    private sealed class Bullet
    {
        public ushort Id;
        public PlayerControl Shooter = null!;
        public Vector2 Pos;
        public Vector2 Dir;
        public float Travelled;
        public float Born;
        public bool Mine;
        public GameObject Go = null!;
        public readonly HashSet<byte> AlreadyHit = new();
    }

    private const float HitRadius = 0.32f;
    private const float HardCapDistance = 250f;
    private const float HardCapSeconds = 25f;

    private static readonly List<Bullet> Live = new();
    private static ushort _nextId = 1;

    public static ushort NextId() => _nextId++;

    public static void Spawn(PlayerControl shooter, ushort id, Vector2 origin, Vector2 dir)
    {
        if (shooter == null)
        {
            return;
        }

        var b = new Bullet
        {
            Id = id,
            Shooter = shooter,
            Pos = origin,
            Dir = dir.normalized,
            Born = Time.time,
            Mine = shooter.AmOwner,
            Go = new GameObject($"GunMod_bullet_{id}"),
        };
        b.Go.transform.position = new Vector3(origin.x, origin.y, -0.02f);
        b.Go.transform.rotation = Quaternion.Euler(0, 0, Visuals.AngleOf(b.Dir));
        var sr = b.Go.AddComponent<SpriteRenderer>();
        sr.sprite = Art.Bullet(0.6f);
        sr.sortingOrder = 60;
        var body = shooter.cosmetics?.currentBodySprite?.BodySprite;
        if (body != null)
        {
            sr.sortingLayerID = body.sortingLayerID;
        }

        sr.enabled = Visuals.CanLocalSee();
        Live.Add(b);
    }

    public static void End(PlayerControl shooter, ushort id, Vector2 at, bool impact)
    {
        for (var i = Live.Count - 1; i >= 0; i--)
        {
            var b = Live[i];
            if (b.Id != id || b.Shooter == null || shooter == null || b.Shooter.PlayerId != shooter.PlayerId)
            {
                continue;
            }

            if (b.Go)
            {
                Object.Destroy(b.Go);
            }

            Live.RemoveAt(i);
        }

        if (impact)
        {
            Visuals.Impact(at);
        }
    }

    public static void ClearAll()
    {
        foreach (var b in Live)
        {
            if (b.Go)
            {
                Object.Destroy(b.Go);
            }
        }

        Live.Clear();
    }

    public static void Tick()
    {
        if (Live.Count == 0)
        {
            return;
        }

        var opts = Opts.Gun;
        var speed = opts.BulletSpeed.Value;
        var maxDist = opts.BulletMaxDistance.Value <= 0 ? HardCapDistance : Mathf.Min(opts.BulletMaxDistance.Value, HardCapDistance);
        var dt = Time.deltaTime;

        for (var i = Live.Count - 1; i >= 0; i--)
        {
            var b = Live[i];
            if (!b.Go || b.Shooter == null)
            {
                Live.RemoveAt(i);
                continue;
            }

            var step = speed * dt;
            var prev = b.Pos;
            var next = prev + b.Dir * step;
            b.Travelled += step;

            var ended = false;
            var endAt = next;
            var impact = false;

            if (b.Mine)
            {
                if (opts.BulletBlockedByWalls && PhysicsHelpers.AnyNonTriggersBetween(prev, b.Dir, step, Constants.ShipOnlyMask))
                {
                    ended = true;
                }
                else
                {
                    foreach (var p in PlayerControl.AllPlayerControls.ToArray())
                    {
                        if (!IsHittable(b, p))
                        {
                            continue;
                        }

                        var hitPoint = ClosestOnSegment(prev, next, p.GetTruePosition());
                        if ((hitPoint - p.GetTruePosition()).sqrMagnitude > HitRadius * HitRadius)
                        {
                            continue;
                        }

                        b.AlreadyHit.Add(p.PlayerId);
                        impact = true;
                        endAt = hitPoint;
                        Net.RpcBulletHit(PlayerControl.LocalPlayer, b.Id, hitPoint.x, hitPoint.y, p.PlayerId);
                        CustomButtonRef.Gun?.OnHit(p);

                        if (!opts.BulletPierces)
                        {
                            ended = true;
                            break;
                        }
                    }
                }

                if (!ended && (b.Travelled >= maxDist || Time.time - b.Born > HardCapSeconds))
                {
                    ended = true;
                }

                if (ended)
                {
                    Net.RpcBulletEnd(PlayerControl.LocalPlayer, b.Id, endAt.x, endAt.y, impact);
                    continue;
                }
            }
            else if (Time.time - b.Born > HardCapSeconds + 5f)
            {
                // The shooter's end message never arrived; clean up quietly.
                Object.Destroy(b.Go);
                Live.RemoveAt(i);
                continue;
            }

            b.Pos = next;
            b.Go.transform.position = new Vector3(next.x, next.y, -0.02f);
        }
    }

    private static bool IsHittable(Bullet b, PlayerControl p)
    {
        if (p == null || p.Data == null || p.Data.IsDead || p.Data.Disconnected || p.inVent || !p.Visible)
        {
            return false;
        }

        if (b.AlreadyHit.Contains(p.PlayerId))
        {
            return false;
        }

        if (p.PlayerId == b.Shooter.PlayerId)
        {
            // A bullet spawns at the muzzle, so self hits only count once it has flown a little.
            return Opts.Gun.CanHitSelf && b.Travelled > 1.0f;
        }

        return true;
    }

    private static Vector2 ClosestOnSegment(Vector2 a, Vector2 b, Vector2 p)
    {
        var ab = b - a;
        var len2 = ab.sqrMagnitude;
        if (len2 < 1e-6f)
        {
            return a;
        }

        var t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / len2);
        return a + ab * t;
    }
}
