# Placeholder effect sprites (bullet, muzzle flash, slash arc, impact) used
# when the final art is missing. Flat colours + dark outline, transparent bg.
from PIL import Image, ImageDraw
import math, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Resources")
LINE = (18, 20, 28, 255)

def save(img, name):
    img.save(os.path.join(OUT, name + ".png"))

# bullet: brass body with copper tip, pointing right, no trail
img = Image.new("RGBA", (512, 256), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
d.rounded_rectangle((60, 78, 380, 178), radius=40, fill=(214, 170, 60, 255), outline=LINE, width=14)
d.pieslice((300, 78, 460, 178), -90, 90, fill=(186, 104, 52, 255), outline=LINE, width=14)
d.rounded_rectangle((60, 78, 120, 178), radius=30, fill=(150, 110, 40, 255), outline=LINE, width=14)
save(img, "bullet_fallback")

# muzzle flash: spiky star pointing right
img = Image.new("RGBA", (512, 512), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
cx, cy = 200, 256
pts = []
for i in range(16):
    a = i * math.pi / 8
    r = 220 if i % 2 == 0 else 110
    pts.append((cx + math.cos(a) * r * (1.25 if math.cos(a) > 0 else 0.7), cy + math.sin(a) * r))
d.polygon(pts, fill=(255, 190, 40, 255), outline=LINE, width=12)
inner = [(cx + (x - cx) * 0.5, cy + (y - cy) * 0.5) for x, y in pts]
d.polygon(inner, fill=(255, 240, 150, 255))
save(img, "muzzle_flash_fallback")

# slash arc: crescent opening to the right
img = Image.new("RGBA", (512, 512), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
d.pieslice((40, 40, 472, 472), -70, 70, fill=(240, 244, 250, 255), outline=LINE, width=12)
d.pieslice((-40, 90, 372, 422), -80, 80, fill=(0, 0, 0, 0))
mask = Image.new("L", (512, 512), 0); md = ImageDraw.Draw(mask)
md.pieslice((40, 40, 472, 472), -70, 70, fill=255)
md.pieslice((-60, 100, 352, 412), -90, 90, fill=0)
arc = Image.new("RGBA", (512, 512), (0, 0, 0, 0)); ad = ImageDraw.Draw(arc)
ad.pieslice((40, 40, 472, 472), -70, 70, fill=(240, 244, 250, 255), outline=LINE, width=12)
ad.pieslice((-60, 100, 352, 412), -90, 90, fill=(0, 0, 0, 0), outline=LINE, width=12)
img = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
img.paste(arc, (0, 0), mask)
save(img, "slash_arc_fallback")

# impact: red/orange burst
img = Image.new("RGBA", (512, 512), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
cx = cy = 256
pts = []
for i in range(20):
    a = i * math.pi / 10
    r = 230 if i % 2 == 0 else 120
    pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
d.polygon(pts, fill=(230, 70, 50, 255), outline=LINE, width=12)
inner = [(cx + (x - cx) * 0.55, cy + (y - cy) * 0.55) for x, y in pts]
d.polygon(inner, fill=(255, 160, 60, 255))
save(img, "bullet_hit_fallback")
print("ok")
