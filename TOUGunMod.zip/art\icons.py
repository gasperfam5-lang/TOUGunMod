# Flat cartoon weapon icons, Among Us button style. Run:
#   blender.exe -b --python icons.py -- gun
#   blender.exe -b --python icons.py -- sword
import bpy, math, os, sys
from mathutils import Matrix

MODE = sys.argv[sys.argv.index("--") + 1] if "--" in sys.argv else "gun"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, f"{MODE}_icon.png")

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
DEPTH = 0.3

def hexc(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) / 255.0 for i in (0, 2, 4))

def flat_mat(name, h):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Color"].default_value = (*hexc(h), 1.0)
    nt.links.new(em.outputs[0], out.inputs[0])
    return m

def box(name, cx, cz, w, h, mat, rot=0.0, bevel=0.0, y=0.0, segs=4):
    bpy.ops.mesh.primitive_cube_add(size=1, location=(cx, y, cz))
    o = bpy.context.active_object
    o.name = name
    o.scale = (w, DEPTH, h)
    o.rotation_euler = (0, math.radians(rot), 0)
    bpy.ops.object.transform_apply(scale=True, rotation=True)
    if bevel > 0:
        b = o.modifiers.new("bev", "BEVEL")
        b.width = bevel
        b.segments = segs
        b.limit_method = "NONE"
    o.data.materials.append(mat)
    return o

def cyl(name, cx, cz, r, mat, y=0.0, depth=DEPTH):
    bpy.ops.mesh.primitive_cylinder_add(radius=r, depth=depth, vertices=48,
                                        location=(cx, y, cz),
                                        rotation=(math.radians(90), 0, 0))
    o = bpy.context.active_object
    o.name = name
    o.data.materials.append(mat)
    return o

def prism(name, pts, mat, y=0.0, depth=DEPTH):
    """Extrude a 2D polygon (x,z) into a solid of thickness `depth`."""
    n = len(pts)
    verts = [(x, y - depth / 2, z) for x, z in pts] + [(x, y + depth / 2, z) for x, z in pts]
    faces = [list(range(n))[::-1], [i + n for i in range(n)]]
    for i in range(n):
        j = (i + 1) % n
        faces.append([i, j, j + n, i + n])
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    o = bpy.data.objects.new(name, me)
    scene.collection.objects.link(o)
    o.data.materials.append(mat)
    return o

def build_gun():
    M_SLIDE  = flat_mat("slide",  "#5B6B85")
    M_SLIDE2 = flat_mat("slide2", "#7C8CA6")
    M_FRAME  = flat_mat("frame",  "#3F4A5E")
    M_GRIP   = flat_mat("grip",   "#A0622D")
    M_GRIP2  = flat_mat("grip2",  "#7E4A20")
    M_DARK   = flat_mat("dark",   "#2A3140")
    M_MUZZLE = flat_mat("muzzle", "#15181F")
    # slide (upper body)
    box("slide", 0.15, 0.62, 2.9, 0.62, M_SLIDE, bevel=0.10)
    box("slide_top", 0.15, 0.86, 2.6, 0.12, M_SLIDE2, bevel=0.03, y=-0.05)
    for i in range(4):
        box(f"serr{i}", -1.05 + i * 0.16, 0.60, 0.06, 0.40, M_DARK, y=-0.16)
    box("sight_f", 1.35, 0.99, 0.10, 0.14, M_DARK, bevel=0.02)
    box("sight_r", -1.10, 0.99, 0.18, 0.14, M_DARK, bevel=0.02)
    # barrel / muzzle
    box("barrel", 1.72, 0.62, 0.30, 0.34, M_FRAME, bevel=0.05)
    cyl("muzzle", 1.87, 0.62, 0.11, M_MUZZLE, y=-0.16, depth=0.05)
    # frame (lower body)
    box("frame", 0.05, 0.22, 2.7, 0.34, M_FRAME, bevel=0.06)
    # hammer, leaning back
    box("hammer", -1.45, 0.72, 0.22, 0.30, M_DARK, rot=-25, bevel=0.04)
    # grip, bottom angled back (toward -X)
    box("grip", -0.95, -0.50, 0.62, 1.30, M_GRIP, rot=18, bevel=0.10)
    box("grip_panel", -0.98, -0.58, 0.36, 0.85, M_GRIP2, rot=18, bevel=0.06, y=-0.12)
    box("mag_base", -1.15, -1.14, 0.62, 0.14, M_DARK, rot=18, bevel=0.03, y=0.02)
    # trigger guard ring tucked against the grip
    bpy.ops.mesh.primitive_torus_add(major_radius=0.32, minor_radius=0.065,
                                     major_segments=48, minor_segments=12,
                                     location=(-0.22, 0.0, -0.2),
                                     rotation=(math.radians(90), 0, 0))
    tg = bpy.context.active_object
    tg.name = "guard"
    tg.data.materials.append(M_FRAME)
    box("trigger", -0.26, -0.14, 0.09, 0.30, M_DARK, rot=15, bevel=0.02, y=-0.08)
    return (0.16, -0.1, 3.9)

def build_sword():
    M_BLADE  = flat_mat("blade",  "#C9D2E0")
    M_FULLER = flat_mat("fuller", "#98A5BA")
    M_EDGE   = flat_mat("edge",   "#E8EDF5")
    M_GUARD  = flat_mat("guard",  "#C99A2E")
    M_GUARD2 = flat_mat("guard2", "#A67A1F")
    M_GRIP   = flat_mat("grip",   "#7E4A20")
    M_WRAP   = flat_mat("wrap",   "#5C3414")
    objs = []
    # blade: tapered, pointing up (+Z)
    objs.append(prism("blade", [(-0.27, 0.0), (0.27, 0.0), (0.27, 2.25), (0.0, 3.0), (-0.27, 2.25)], M_BLADE))
    objs.append(prism("fuller", [(-0.06, 0.15), (0.06, 0.15), (0.06, 2.2), (0.0, 2.45), (-0.06, 2.2)], M_FULLER, y=-0.05))
    # crossguard
    objs.append(box("cross", 0.0, -0.08, 1.35, 0.24, M_GUARD, bevel=0.06))
    objs.append(box("cross_l", -0.62, -0.08, 0.16, 0.34, M_GUARD2, bevel=0.05, y=-0.02))
    objs.append(box("cross_r", 0.62, -0.08, 0.16, 0.34, M_GUARD2, bevel=0.05, y=-0.02))
    # grip with wrap stripes
    objs.append(box("grip", 0.0, -0.66, 0.32, 0.95, M_GRIP, bevel=0.06))
    for i in range(4):
        objs.append(box(f"wrap{i}", 0.0, -0.32 - i * 0.2, 0.32, 0.07, M_WRAP, rot=12, y=-0.06))
    # pommel
    objs.append(cyl("pommel", 0.0, -1.26, 0.2, M_GUARD))
    objs.append(cyl("pommel_c", 0.0, -1.26, 0.08, M_GUARD2, y=-0.06))
    # tilt whole sword so the tip points up-right
    R = Matrix.Rotation(math.radians(45), 4, "Y")
    for o in objs:
        o.matrix_world = R @ o.matrix_world
    return (0.6, 0.6, 4.4)

cx, cz, ortho = build_gun() if MODE == "gun" else build_sword()

cam_data = bpy.data.cameras.new("cam")
cam_data.type = "ORTHO"
cam_data.ortho_scale = ortho
cam = bpy.data.objects.new("cam", cam_data)
cam.location = (cx, -10, cz)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.collection.objects.link(cam)
scene.camera = cam

scene.render.engine = "BLENDER_EEVEE_NEXT"
scene.render.resolution_x = 512
scene.render.resolution_y = 512
scene.render.film_transparent = True
scene.render.image_settings.file_format = "PNG"
scene.render.image_settings.color_mode = "RGBA"
scene.view_settings.view_transform = "Standard"
scene.eevee.taa_render_samples = 16

scene.render.use_freestyle = True
scene.render.line_thickness_mode = "ABSOLUTE"
scene.render.line_thickness = 2.5
vl = scene.view_layers[0]
vl.use_freestyle = True
fs = vl.freestyle_settings
fs.crease_angle = math.radians(150)
ls = fs.linesets[0] if fs.linesets else fs.linesets.new("Lines")
ls.select_silhouette = True
ls.select_border = True
ls.select_crease = True
ls.select_contour = False
ls.select_external_contour = False
lsty = bpy.data.linestyles.new("line")
ls.linestyle = lsty
lsty.color = (0.06, 0.07, 0.10)
lsty.thickness = 2.5
lsty.caps = "ROUND"

scene.render.filepath = OUT
bpy.ops.render.render(write_still=True)
print("WROTE", OUT)
