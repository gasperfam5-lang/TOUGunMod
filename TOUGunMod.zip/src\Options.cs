using MiraAPI.GameOptions;
using MiraAPI.GameOptions.OptionTypes;
using MiraAPI.PluginLoading;
using MiraAPI.Utilities;
using UnityEngine;

namespace TOUGunMod;

/// <summary>
/// Every option for one weapon. The gun and the sword each get an instance so
/// the host can tune them independently. Titles carry the weapon name because
/// option titles must be unique across the whole mod.
/// </summary>
[MiraIgnore]
public abstract class WeaponOptions : AbstractOptionGroup
{
    protected WeaponOptions(string w, bool gun)
    {
        Func<bool> on = () => Enabled!.Value;
        Func<bool> onGun = () => Enabled!.Value && gun;
        Func<bool> onSword = () => Enabled!.Value && !gun;
        var lw = w.ToLowerInvariant();

        Enabled = new($"{w} enabled", true);

        CrewmatesGet = T($"Crewmates get a {lw}", true, on);
        ImpostorsGet = T($"Impostors get a {lw}", true, on);
        NeutralsGet = T($"Neutrals get a {lw}", true, on);

        var use = gun ? "shots" : "swings";
        CrewmateUses = N($"Crewmate {lw} {use}", 1, 0, 20, 1, MiraNumberSuffixes.None, true, on);
        ImpostorUses = N($"Impostor {lw} {use}", 0, 0, 20, 1, MiraNumberSuffixes.None, true, on);
        NeutralUses = N($"Neutral {lw} {use}", 0, 0, 20, 1, MiraNumberSuffixes.None, true, on);

        CrewmateCooldown = N($"Crewmate {lw} cooldown", 25, 0, 120, 2.5f, MiraNumberSuffixes.Seconds, false, on);
        ImpostorCooldown = N($"Impostor {lw} cooldown", 25, 0, 120, 2.5f, MiraNumberSuffixes.Seconds, false, on);
        NeutralCooldown = N($"Neutral {lw} cooldown", 25, 0, 120, 2.5f, MiraNumberSuffixes.Seconds, false, on);
        CooldownAtRoundStart = T($"{w} cooldown starts at round start", true, on);

        var back = gun ? "shot back" : "swing back";
        CrewRefundImp = T($"Crewmate gets {lw} {back} after hitting an impostor", true, on);
        CrewRefundNeut = T($"Crewmate gets {lw} {back} after hitting a neutral", true, on);
        CrewRefundCrew = T($"Crewmate gets {lw} {back} after hitting a crewmate", false, on);
        ImpRefundCrew = T($"Impostor gets {lw} {back} after hitting a crewmate", true, on);
        ImpRefundNeut = T($"Impostor gets {lw} {back} after hitting a neutral", true, on);
        ImpRefundImp = T($"Impostor gets {lw} {back} after hitting an impostor", false, on);
        NeutRefundCrew = T($"Neutral gets {lw} {back} after hitting a crewmate", true, on);
        NeutRefundImp = T($"Neutral gets {lw} {back} after hitting an impostor", true, on);
        NeutRefundNeut = T($"Neutral gets {lw} {back} after hitting a neutral", true, on);

        CrewDiesCrew = T($"Crewmate dies when {lw} hits a crewmate", true, on);
        CrewDiesImp = T($"Crewmate dies when {lw} hits an impostor", false, on);
        CrewDiesNeut = T($"Crewmate dies when {lw} hits a neutral", false, on);
        ImpDiesCrew = T($"Impostor dies when {lw} hits a crewmate", false, on);
        ImpDiesImp = T($"Impostor dies when {lw} hits an impostor", false, on);
        ImpDiesNeut = T($"Impostor dies when {lw} hits a neutral", false, on);
        NeutDiesCrew = T($"Neutral dies when {lw} hits a crewmate", false, on);
        NeutDiesImp = T($"Neutral dies when {lw} hits an impostor", false, on);
        NeutDiesNeut = T($"Neutral dies when {lw} hits a neutral", false, on);

        // gun only
        BulletSpeed = N("Bullet speed", 12, 2, 60, 1, MiraNumberSuffixes.None, false, onGun);
        BulletMaxDistance = N("Bullet max distance", 0, 0, 100, 5, MiraNumberSuffixes.None, true, onGun);
        BulletBlockedByWalls = T("Bullet blocked by walls", false, onGun);
        BulletPierces = T("Bullet goes through players it hits", false, onGun);
        CanHitSelf = T("Your own bullet can hit you", false, onGun);

        // sword only
        SwordRange = N("Sword range", 1.8f, 0.5f, 5, 0.1f, MiraNumberSuffixes.None, false, onSword);
        SwordArc = N("Sword swing arc", 120, 30, 360, 10, MiraNumberSuffixes.None, false, onSword);
        SwordHitsAll = T("Sword hits everyone in the arc", false, onSword);

        Aim = new ModdedEnumOption<AimMode>($"{w} aim", AimMode.Mouse, ["Mouse", "Facing"]) { Visible = on };
        AimTimeLimit = N($"{w} auto-holsters after", 0, 0, 30, 1, MiraNumberSuffixes.Seconds, true, on);
        VisibleToOthers = T($"Others can see your {lw} while aiming", true, on);
        ImpostorsKeepKill = T($"Impostors keep their normal kill with the {lw}", true, on);
    }

    public ModdedToggleOption Enabled { get; }

    public ModdedToggleOption CrewmatesGet { get; }
    public ModdedToggleOption ImpostorsGet { get; }
    public ModdedToggleOption NeutralsGet { get; }

    public ModdedNumberOption CrewmateUses { get; }
    public ModdedNumberOption ImpostorUses { get; }
    public ModdedNumberOption NeutralUses { get; }

    public ModdedNumberOption CrewmateCooldown { get; }
    public ModdedNumberOption ImpostorCooldown { get; }
    public ModdedNumberOption NeutralCooldown { get; }
    public ModdedToggleOption CooldownAtRoundStart { get; }

    public ModdedToggleOption CrewRefundImp { get; }
    public ModdedToggleOption CrewRefundNeut { get; }
    public ModdedToggleOption CrewRefundCrew { get; }
    public ModdedToggleOption ImpRefundCrew { get; }
    public ModdedToggleOption ImpRefundNeut { get; }
    public ModdedToggleOption ImpRefundImp { get; }
    public ModdedToggleOption NeutRefundCrew { get; }
    public ModdedToggleOption NeutRefundImp { get; }
    public ModdedToggleOption NeutRefundNeut { get; }

    public ModdedToggleOption CrewDiesCrew { get; }
    public ModdedToggleOption CrewDiesImp { get; }
    public ModdedToggleOption CrewDiesNeut { get; }
    public ModdedToggleOption ImpDiesCrew { get; }
    public ModdedToggleOption ImpDiesImp { get; }
    public ModdedToggleOption ImpDiesNeut { get; }
    public ModdedToggleOption NeutDiesCrew { get; }
    public ModdedToggleOption NeutDiesImp { get; }
    public ModdedToggleOption NeutDiesNeut { get; }

    public ModdedNumberOption BulletSpeed { get; }
    public ModdedNumberOption BulletMaxDistance { get; }
    public ModdedToggleOption BulletBlockedByWalls { get; }
    public ModdedToggleOption BulletPierces { get; }
    public ModdedToggleOption CanHitSelf { get; }

    public ModdedNumberOption SwordRange { get; }
    public ModdedNumberOption SwordArc { get; }
    public ModdedToggleOption SwordHitsAll { get; }

    public ModdedEnumOption<AimMode> Aim { get; }
    public ModdedNumberOption AimTimeLimit { get; }
    public ModdedToggleOption VisibleToOthers { get; }
    public ModdedToggleOption ImpostorsKeepKill { get; }

    // ---- lookups ----

    public bool TeamGets(Team team) => team switch
    {
        Team.Impostor => ImpostorsGet,
        Team.Neutral => NeutralsGet,
        _ => CrewmatesGet,
    };

    /// <summary>Starting uses for a team; 0 means infinite.</summary>
    public int Uses(Team team) => (int)(team switch
    {
        Team.Impostor => ImpostorUses.Value,
        Team.Neutral => NeutralUses.Value,
        _ => CrewmateUses.Value,
    });

    public float Cooldown(Team team) => team switch
    {
        Team.Impostor => ImpostorCooldown.Value,
        Team.Neutral => NeutralCooldown.Value,
        _ => CrewmateCooldown.Value,
    };

    public bool Refund(Team attacker, Team victim) => (attacker, victim) switch
    {
        (Team.Crewmate, Team.Impostor) => CrewRefundImp,
        (Team.Crewmate, Team.Neutral) => CrewRefundNeut,
        (Team.Crewmate, Team.Crewmate) => CrewRefundCrew,
        (Team.Impostor, Team.Crewmate) => ImpRefundCrew,
        (Team.Impostor, Team.Neutral) => ImpRefundNeut,
        (Team.Impostor, Team.Impostor) => ImpRefundImp,
        (Team.Neutral, Team.Crewmate) => NeutRefundCrew,
        (Team.Neutral, Team.Impostor) => NeutRefundImp,
        _ => NeutRefundNeut,
    };

    public bool AttackerDies(Team attacker, Team victim) => (attacker, victim) switch
    {
        (Team.Crewmate, Team.Crewmate) => CrewDiesCrew,
        (Team.Crewmate, Team.Impostor) => CrewDiesImp,
        (Team.Crewmate, Team.Neutral) => CrewDiesNeut,
        (Team.Impostor, Team.Crewmate) => ImpDiesCrew,
        (Team.Impostor, Team.Impostor) => ImpDiesImp,
        (Team.Impostor, Team.Neutral) => ImpDiesNeut,
        (Team.Neutral, Team.Crewmate) => NeutDiesCrew,
        (Team.Neutral, Team.Impostor) => NeutDiesImp,
        _ => NeutDiesNeut,
    };

    private static ModdedToggleOption T(string title, bool def, Func<bool> visible) =>
        new(title, def) { Visible = visible };

    private static ModdedNumberOption N(string title, float def, float min, float max, float inc,
        MiraNumberSuffixes suffix, bool zeroInfinity, Func<bool> visible) =>
        new(title, def, min, max, inc, suffix, null, zeroInfinity) { Visible = visible };
}

public sealed class GunOptions : WeaponOptions
{
    public GunOptions() : base("Gun", true) { }
    public override string GroupName => "Gun";
    public override uint GroupPriority => 0;
    public override Color GroupColor => new(0.42f, 0.5f, 0.62f);
}

public sealed class SwordOptions : WeaponOptions
{
    public SwordOptions() : base("Sword", false) { }
    public override string GroupName => "Sword";
    public override uint GroupPriority => 1;
    public override Color GroupColor => new(0.79f, 0.6f, 0.18f);
}

public sealed class GeneralOptions : AbstractOptionGroup
{
    public override string GroupName => "Gun and Sword general";
    public override uint GroupPriority => 2;
    public override Color GroupColor => new(0.8f, 0.3f, 0.3f);

    private static bool Any => OptionGroupSingleton<GunOptions>.Instance.Enabled || OptionGroupSingleton<SwordOptions>.Instance.Enabled;

    public ModdedToggleOption LeaveBody { get; } = new("Weapon kills leave a body", true) { Visible = () => Any };
    public ModdedToggleOption KillAnimation { get; } = new("Weapon kills show the kill animation", true) { Visible = () => Any };
    public ModdedToggleOption GhostsSeeWeapons { get; } = new("Ghosts can see weapons and bullets", true) { Visible = () => Any };
    public ModdedToggleOption ResetAfterMeeting { get; } = new("Weapons refill after every meeting", false) { Visible = () => Any };
    public ModdedToggleOption OneWeaponAtATime { get; } = new("Only one weapon can be drawn at a time", true) { Visible = () => Any };
    public ModdedToggleOption AnnounceKills { get; } = new("Announce weapon kills in chat", true) { Visible = () => Any };
    public ModdedToggleOption ShowHitPopup { get; } = new("Show a popup when you hit someone", true) { Visible = () => Any };
}

public static class Opts
{
    public static GunOptions Gun => OptionGroupSingleton<GunOptions>.Instance;
    public static SwordOptions Sword => OptionGroupSingleton<SwordOptions>.Instance;
    public static GeneralOptions General => OptionGroupSingleton<GeneralOptions>.Instance;

    public static WeaponOptions For(Weapon weapon) => weapon == Weapon.Gun ? Gun : Sword;
}
